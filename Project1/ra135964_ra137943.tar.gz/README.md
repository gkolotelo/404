[rotulo:] [instrucao] [# comentario]

[instrucao] [# comentario]

[# comentario]

[rotulo:]

[instrucao] [# comentario]

[instrucao]




Definitions:
    Label: ': appended'
    Comment: '# prepended'
    Instruction: 


Duvidas:
    precisa imprimir para ser simulado? I.E. com os endereços de memória
    
    



    add
    mul
    jump(start)
start:
    div
    lsh



0f 3333     05 6666
start_ph    

start: 3

